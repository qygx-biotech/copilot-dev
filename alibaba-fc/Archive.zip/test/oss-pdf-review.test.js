const assert = require("node:assert/strict");
const test = require("node:test");
const fs = require("node:fs");
const path = require("node:path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const OSS = require("ali-oss");

process.env.JWT_SECRET = "unit-test-jwt-secret";
process.env.ADMIN_ACCOUNT = "paper-reviewer@example.com";
process.env.ADMIN_PASSWORD_HASH = bcrypt.hashSync("test-password", 4);
process.env.OSS_BUCKET = "biodesign-copilot-files-2026";
process.env.OSS_REGION = "oss-cn-beijing";
process.env.OSS_INTERNAL_ENDPOINT =
  "https://oss-cn-beijing-internal.aliyuncs.com";
process.env.OSS_PUBLIC_ENDPOINT = "https://oss-cn-beijing.aliyuncs.com";
process.env.REQUESTY_API_KEY = "requesty-test-key";
process.env.REQUESTY_MODEL = "requesty-test-model";
process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "true";

const objectStore = new Map();
let deleteCalls = 0;
let pdfGetCalls = 0;
let llmFetchCalls = 0;
const queuedChatCompletionTexts = [];
const queuedChatCompletionMessages = [];
const queuedRouterCompletionTexts = [];
const queuedCorpusMapCompletionTexts = [];
const queuedChatHttpStatuses = [];
const capturedLlmRequests = [];

OSS.prototype.getObjectMeta = async function getObjectMeta(objectKey) {
  assert.match(
    String(this.options.endpoint?.href || this.options.endpoint),
    /oss-cn-beijing-internal\.aliyuncs\.com/
  );
  const object = objectStore.get(objectKey);
  if (!object) {
    const error = new Error("The specified key does not exist.");
    error.code = "NoSuchKey";
    error.status = 404;
    error.requestId = "oss-missing-request";
    throw error;
  }

  return {
    status: 200,
    res: {
      headers: {
        "content-length": String(object.buffer.length),
        "content-type": object.contentType
      }
    }
  };
};

OSS.prototype.get = async function get(objectKey) {
  const object = objectStore.get(objectKey);
  if (!object) {
    const error = new Error("The specified key does not exist.");
    error.code = "NoSuchKey";
    error.status = 404;
    throw error;
  }
  if (objectKey.toLowerCase().endsWith(".pdf")) pdfGetCalls += 1;
  return { content: object.buffer };
};

OSS.prototype.put = async function put(objectKey, content, options = {}) {
  objectStore.set(objectKey, {
    buffer: Buffer.isBuffer(content) ? content : Buffer.from(content || ""),
    contentType:
      options.headers?.["Content-Type"] || "application/octet-stream",
    lastModified: new Date().toISOString()
  });
  return { name: objectKey };
};

OSS.prototype.listV2 = async function listV2(query = {}) {
  assert.match(
    String(this.options.endpoint?.href || this.options.endpoint),
    /oss-cn-beijing-internal\.aliyuncs\.com/
  );
  const prefix = String(query.prefix || "");
  const objects = [...objectStore.entries()]
    .filter(([objectKey]) => objectKey.startsWith(prefix))
    .map(([name, object]) => ({
      name,
      size: object.buffer.length,
      lastModified: object.lastModified || "2026-08-14T02:00:00.000Z"
    }));

  return {
    objects,
    isTruncated: false,
    nextContinuationToken: null
  };
};

OSS.prototype.delete = async function deleteObject(objectKey) {
  deleteCalls += 1;
  objectStore.delete(objectKey);
  return {};
};

global.fetch = async (_url, options = {}) => {
  llmFetchCalls += 1;
  const request = JSON.parse(options.body || "{}");
  capturedLlmRequests.push(request);
  const systemMessage = String(request.messages?.[0]?.content || "");
  if (
    !systemMessage.includes("one excerpt of an academic paper") &&
    !systemMessage.includes("combine evidence summaries") &&
    queuedChatHttpStatuses.length
  ) {
    const status = queuedChatHttpStatuses.shift();
    if (status !== 200) {
      return new Response(JSON.stringify({ error: { message: "transient" } }), {
        status,
        headers: {
          "Content-Type": "application/json",
          "Retry-After": "0"
        }
      });
    }
  }
  let content;
  let messageOverride = null;

  if (systemMessage.includes("lightweight context and memory router")) {
    content = queuedRouterCompletionTexts.length
      ? queuedRouterCompletionTexts.shift()
      : JSON.stringify({
          use_literature: false,
          paper_ids: [],
          use_project_memory: false,
          memory_ids: [],
          reason: "No local context is needed."
        });
  } else if (
    systemMessage.includes("fresh-context corpus mapping worker") ||
    systemMessage.includes("corpus-map JSON repair worker")
  ) {
    content = queuedCorpusMapCompletionTexts.length
      ? queuedCorpusMapCompletionTexts.shift()
      : JSON.stringify({
          title: "Mapped paper",
          relevance: "high",
          research_question: null,
          themes: ["enzyme engineering"],
          methods: [],
          organisms: [],
          genes: [],
          proteins: [],
          pathways: [],
          experimental_strategies: [],
          major_findings: [],
          limitations: [],
          connections_to_other_topics: [],
          notes: null
        });
  } else if (systemMessage.includes("one excerpt of an academic paper")) {
    content = JSON.stringify({
      summary: "This excerpt describes a controlled paper review experiment.",
      research_question: "Can the proposed review workflow preserve evidence?",
      methods: "A controlled comparison with explicit observations.",
      key_results: ["The workflow retained the source evidence."],
      limitations: ["The excerpt reports a small validation study."],
      main_conclusion: "The workflow was suitable for this validation."
    });
  } else if (systemMessage.includes("combine evidence summaries")) {
    content = JSON.stringify({
      summary: "The paper evaluates a controlled evidence-review workflow.",
      research_question: "Can the workflow preserve and review paper evidence?",
      methods: "The authors used a controlled comparison and recorded outcomes.",
      key_results: ["Source evidence remained available after review."],
      limitations: ["The validation was limited in scale."],
      main_conclusion: "The tested workflow preserved evidence successfully."
    });
  } else {
    if (queuedChatCompletionMessages.length) {
      messageOverride = queuedChatCompletionMessages.shift();
    } else {
      content = queuedChatCompletionTexts.length
        ? queuedChatCompletionTexts.shift()
        : JSON.stringify({
            reply: "The stored PDF evidence was available to Side Chat.",
            project: {
              summary: "Stored PDF reviewed.",
              organism: "Not applicable",
              missingInformation: [],
              safetyLevel: "Planning review",
              safetyNotes: "Human review remains required.",
              draftMemo: "The stored PDF was included as evidence."
            }
          });
    }
  }

  return new Response(
    JSON.stringify({ choices: [{ message: messageOverride || { content } }] }),
    { status: 200, headers: { "Content-Type": "application/json" } }
  );
};

const { handler, _test } = require("../index");

const context = {
  requestId: "fc-unit-test-request",
  credentials: {
    accessKeyId: "STS.unit-test-id",
    accessKeySecret: "unit-test-secret",
    securityToken: "unit-test-security-token"
  }
};

const authToken = jwt.sign(
  { account: process.env.ADMIN_ACCOUNT, role: "admin" },
  process.env.JWT_SECRET
);

function apiEvent(method, path, body, authenticated = true) {
  return {
    httpMethod: method,
    path,
    headers: authenticated
      ? { authorization: `Bearer ${authToken}` }
      : {},
    body: body === undefined ? undefined : JSON.stringify(body)
  };
}

function parseResponse(response) {
  return response.body ? JSON.parse(response.body) : null;
}

function validNativePaperAnalysis() {
  return {
    summary: "The paper reports an evidence-backed whole-document analysis.",
    research_question: null,
    themes: ["enzyme engineering"],
    methods: ["activity assay"],
    key_findings: [
      {
        claim: "The tested variant improved activity.",
        evidence_refs: ["paper-native:p4"]
      }
    ],
    limitations: ["One assay condition was reported."],
    evidence_refs: ["paper-native:p4"],
    notes: null
  };
}

function validNativePaperCard(overrides = {}) {
  return {
    source_identity: {
      paper_id: "paper-card-native",
      content_hash: "sha256:paper-card-native"
    },
    title: "Native Paper Card",
    authors: ["Test Author"],
    year: 2025,
    abstract_summary: "A whole-paper summary.",
    research_question: "How does EctD activity change?",
    major_findings: [{
      claim: "The tested variant improved EctD activity.",
      citations: [{ page: 4, quote: "variant improved EctD activity" }]
    }],
    methods: ["activity assay"],
    methods_summary: "EctD activity was measured with a controlled assay.",
    organisms: ["Escherichia coli"],
    genes: ["ectD"],
    proteins: ["EctD"],
    pathways: ["hydroxyectoine biosynthesis"],
    metabolites: ["hydroxyectoine"],
    experimental_conditions: ["30 degrees C"],
    measurements: ["specific activity"],
    important_results: [],
    limitations: ["One assay condition was reported."],
    keywords: ["EctD"],
    topics: ["enzyme engineering"],
    short_summary: "The paper characterizes an EctD variant.",
    main_conclusion: "The variant improved activity under the tested condition.",
    ...overrides
  };
}

function validCorpusMapJson(evidenceRef = "paper-a:p8:paper-a-P8-C2") {
  return {
    title: "Selected EctD study",
    relevance: "high",
    research_question: null,
    themes: ["EctD variants"],
    methods: ["activity assay"],
    organisms: [],
    genes: ["ectD"],
    proteins: ["EctD"],
    pathways: [],
    experimental_strategies: ["variant comparison"],
    major_findings: [
      {
        claim: "A163V improved the reported activity.",
        evidence_refs: [evidenceRef]
      }
    ],
    limitations: ["single reported condition"],
    connections_to_other_topics: [],
    notes: null
  };
}

test("frontend upload does not automatically invoke PDF review", () => {
  const frontendSource = fs.readFileSync(
    path.join(__dirname, "../../docs/app.js"),
    "utf8"
  );
  const workspaceSource = fs.readFileSync(
    path.join(__dirname, "../../docs/workspace-manager.js"),
    "utf8"
  );
  const contextSource = fs.readFileSync(
    path.join(__dirname, "../../docs/project-context-service.js"),
    "utf8"
  );
  const uploadStart = frontendSource.indexOf("async function uploadPdfToOss");
  const uploadEnd = frontendSource.indexOf(
    "async function syncStoredPdfDocuments",
    uploadStart
  );
  const uploadFunction = frontendSource.slice(uploadStart, uploadEnd);

  assert.ok(uploadStart >= 0 && uploadEnd > uploadStart);
  assert.doesNotMatch(uploadFunction, /\/api\/documents\/review/);
  assert.match(frontendSource, /USE_OSS_WORKSPACE_STORAGE = false/);
  assert.match(frontendSource, /projectContextService\.buildContext/);
  assert.match(contextSource, /ensureSourceReady/);
  assert.match(workspaceSource, /showDirectoryPicker/);
  assert.match(workspaceSource, /scanDirectoryTree/);
  assert.doesNotMatch(frontendSource, /await syncStoredPdfDocuments\(\)/);
  assert.match(frontendSource, /addSideChatThinking/);
  assert.doesNotMatch(frontendSource, /SIDE_CHAT_HISTORY_STORAGE_KEY/);
  assert.match(contextSource, /\.biodesign\/chat\/conversations/);
  assert.match(frontendSource, /persistSideChatConversation/);
});

function makeMachineReadablePdf() {
  const lines = [
    "A machine readable academic paper evaluates a controlled evidence review workflow.",
    "The research question asks whether source documents remain available after analysis.",
    "The methods use a controlled comparison with explicit observations and recorded outcomes.",
    "The key result is that source evidence remains available after the review is completed.",
    "The authors note that the validation is small and should be repeated on more documents.",
    "The main conclusion is that persistent storage supports a reproducible review workflow."
  ];
  const escapedLines = lines.map((line) =>
    line.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)")
  );
  const content = [
    "BT",
    "/F1 11 Tf",
    "72 730 Td",
    ...escapedLines.flatMap((line, index) => [
      index ? "0 -24 Td" : "",
      `(${line}) Tj`
    ]).filter(Boolean),
    "ET"
  ].join("\n");
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
    `<< /Length ${Buffer.byteLength(content)} >>\nstream\n${content}\nendstream`,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"
  ];

  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets[index + 1] = Buffer.byteLength(pdf);
    pdf += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xrefOffset = Buffer.byteLength(pdf);
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let index = 1; index <= objects.length; index += 1) {
    pdf += `${String(offsets[index]).padStart(10, "0")} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  return Buffer.from(pdf);
}

test("existing login and CORS preflight still work", async () => {
  const preflight = await handler(apiEvent("OPTIONS", "/api/login"), context);
  assert.equal(preflight.statusCode, 204);

  const login = await handler(
    apiEvent(
      "POST",
      "/api/login",
      { account: process.env.ADMIN_ACCOUNT, password: "test-password" },
      false
    ),
    context
  );
  assert.equal(login.statusCode, 200);
  assert.equal(parseResponse(login).ok, true);
});

test("document endpoints reject unauthenticated access", async () => {
  const [
    listResponse,
    uploadResponse,
    reviewResponse,
    deleteResponse,
    localChunkResponse,
    localSynthesisResponse,
    corpusMapResponse,
    nativePdfResponse,
    combinedTextResponse,
    contextRouterResponse
  ] = await Promise.all([
    handler(apiEvent("GET", "/api/documents", undefined, false), context),
    handler(
      apiEvent(
        "POST",
        "/api/documents/upload-url",
        { filename: "paper.pdf", contentType: "application/pdf", size: 1000 },
        false
      ),
      context
    ),
    handler(
      apiEvent(
        "POST",
        "/api/documents/review",
        { objectKey: "uploads/not-authorized/paper.pdf" },
        false
      ),
      context
    ),
    handler(
      apiEvent(
        "POST",
        "/api/documents/delete",
        { objectKey: "uploads/not-authorized/paper.pdf" },
        false
      ),
      context
    ),
    handler(
      apiEvent(
        "POST",
        "/api/literature/summarize-chunk",
        { filename: "local.pdf", chunkIndex: 0, totalChunks: 1, text: "evidence" },
        false
      ),
      context
    ),
    handler(
      apiEvent(
        "POST",
        "/api/literature/synthesize",
        { filename: "local.pdf", chunkSummaries: [{ summary: "evidence" }] },
        false
      ),
      context
    ),
    handler(
      apiEvent(
        "POST",
        "/api/corpus/map-paper",
        { paperId: "paper-a", contentHash: "sha256:test", question: "Q", evidence: [] },
        false
      ),
      context
    ),
    handler(
      apiEvent(
        "POST",
        "/api/literature/analyze-pdf-native",
        {
          paperId: "paper-a",
          contentHash: "sha256:test",
          task: "Summarize the paper.",
          fileData: "data:application/pdf;base64,JVBERi0xLjQ="
        },
        false
      ),
      context
    ),
    handler(
      apiEvent(
        "POST",
        "/api/literature/create-paper-card-from-text",
        {
          paperId: "paper-a",
          contentHash: "sha256:test",
          text: "# Page 1\nevidence"
        },
        false
      ),
      context
    ),
    handler(
      apiEvent(
        "POST",
        "/api/context/route",
        { userQuery: "Which paper?", literatureIndex: [] },
        false
      ),
      context
    )
  ]);

  assert.equal(listResponse.statusCode, 401);
  assert.equal(uploadResponse.statusCode, 401);
  assert.equal(reviewResponse.statusCode, 401);
  assert.equal(deleteResponse.statusCode, 401);
  assert.equal(localChunkResponse.statusCode, 401);
  assert.equal(localSynthesisResponse.statusCode, 401);
  assert.equal(corpusMapResponse.statusCode, 401);
  assert.equal(nativePdfResponse.statusCode, 401);
  assert.equal(combinedTextResponse.statusCode, 401);
  assert.equal(contextRouterResponse.statusCode, 401);
});

test("local literature endpoints are stateless and never read or write OSS", async () => {
  const pdfReadsBefore = pdfGetCalls;
  const objectsBefore = objectStore.size;
  const chunkResponse = await handler(
    apiEvent("POST", "/api/literature/summarize-chunk", {
      filename: "../local-paper.pdf",
      chunkIndex: 0,
      totalChunks: 1,
      text: "Machine-readable evidence from a local academic PDF. ".repeat(20),
      language: "en"
    }),
    context
  );
  const chunkBody = parseResponse(chunkResponse);
  assert.equal(chunkResponse.statusCode, 200);
  assert.equal(chunkBody.ok, true);
  assert.equal(chunkBody.chunkSummary.summary.includes("controlled"), true);

  const synthesisResponse = await handler(
    apiEvent("POST", "/api/literature/synthesize", {
      filename: "/Users/example/private/local-paper.pdf",
      size: 1200,
      lastModified: 1780000000000,
      pageCount: 5,
      extractionTruncated: false,
      chunkSummaries: [chunkBody.chunkSummary],
      language: "en"
    }),
    context
  );
  const synthesisBody = parseResponse(synthesisResponse);
  assert.equal(synthesisResponse.statusCode, 200);
  assert.equal(synthesisBody.ok, true);
  assert.equal(synthesisBody.summary.summary.includes("controlled"), true);
  assert.equal(synthesisBody.model, process.env.REQUESTY_MODEL);
  assert.equal(pdfGetCalls, pdfReadsBefore);
  assert.equal(objectStore.size, objectsBefore);

  const lastRequest = capturedLlmRequests.at(-1);
  const userMessage = lastRequest.messages.at(-1).content;
  assert.match(userMessage, /local-paper\.pdf/);
  assert.doesNotMatch(userMessage, /Users\/example|private\//);
  assert.doesNotMatch(userMessage, /objectKey|OSS/);
});

test("corpus paper mapping uses a fresh bounded context and validates evidence refs", async () => {
  const allowedRef = "paper-a:p8:paper-a-P8-C2";
  const requestStart = capturedLlmRequests.length;
  queuedCorpusMapCompletionTexts.push(
    JSON.stringify({
      title: "Selected EctD study",
      relevance: "high",
      research_question: "Which EctD variants improved activity?",
      themes: ["EctD variants"],
      methods: ["activity assay"],
      organisms: [],
      genes: ["ectD"],
      proteins: ["EctD"],
      pathways: [],
      experimental_strategies: ["variant comparison"],
      major_findings: [
        {
          claim: "A163V improved the reported activity.",
          evidence_refs: [allowedRef]
        }
      ],
      limitations: ["single reported condition"],
      connections_to_other_topics: [],
      notes: null
    })
  );
  const pdfReadsBefore = pdfGetCalls;
  const response = await handler(
    apiEvent("POST", "/api/corpus/map-paper", {
      paperId: "paper-a",
      contentHash: "sha256:abc123",
      question: "Which EctD variants improved activity?",
      evidence: [
        {
          evidenceRef: allowedRef,
          text: "The A163V variant improved activity in the reported assay."
        }
      ],
      language: "en"
    }),
    context
  );
  const body = parseResponse(response);

  assert.equal(response.statusCode, 200);
  assert.equal(body.ok, true);
  assert.equal(body.mapResult.paperId, "paper-a");
  assert.deepEqual(body.mapResult.findings[0].evidenceRefs, [allowedRef]);
  assert.equal(body.mapperDiagnostics.schemaValidationDetails.length, 0);
  assert.equal(body.mapperDiagnostics.repairAttempted, false);
  assert.equal(pdfGetCalls, pdfReadsBefore);
  const requests = capturedLlmRequests.slice(requestStart);
  assert.equal(requests.length, 1);
  const request = requests[0];
  assert.equal(request.messages.length, 2);
  assert.equal(request.response_format.type, "json_schema");
  assert.equal(request.response_format.json_schema.strict, true);
  assert.match(request.messages[0].content, /fresh-context corpus mapping worker/);
  assert.doesNotMatch(request.messages.at(-1).content, /conversation|chat history/i);
});

test("Requesty native PDF uses private base64 input and strict schema when the model supports the combination", async () => {
  const previous = {
    model: process.env.REQUESTY_PDF_MODEL,
    pdf: process.env.REQUESTY_PDF_ENABLED,
    schema: process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA,
    combination: process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA
  };
  process.env.REQUESTY_PDF_MODEL = "openai/gpt-4.1";
  process.env.REQUESTY_PDF_ENABLED = "true";
  process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "true";
  process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA = "true";
  const requestStart = capturedLlmRequests.length;
  queuedChatCompletionTexts.push(JSON.stringify(validNativePaperAnalysis()));
  try {
    const response = await handler(
      apiEvent("POST", "/api/literature/analyze-pdf-native", {
        paperId: "paper-native",
        filename: "/private/research/paper-native.pdf",
        contentHash: "sha256:native",
        task: "Summarize the whole paper, including its figures.",
        purpose: "whole-paper-summary",
        responseSchema: "paper_analysis",
        evidenceRefs: ["paper-native:p4"],
        fileData: `data:application/pdf;base64,${Buffer.from("%PDF-1.4\nprivate-scientific-content").toString("base64")}`
      }),
      context
    );
    const body = parseResponse(response);
    const requests = capturedLlmRequests.slice(requestStart);

    assert.equal(response.statusCode, 200);
    assert.equal(body.analysis.summary.includes("whole-document"), true);
    assert.equal(body.model, "openai-responses/gpt-4.1");
    assert.equal(body.diagnostics.structuredOutputMode, "native-pdf+json_schema");
    assert.equal(requests.length, 1);
    assert.equal(requests[0].response_format.type, "json_schema");
    assert.equal(requests[0].response_format.json_schema.strict, true);
    const filePart = requests[0].messages[1].content.find(
      (part) => part.type === "input_file"
    );
    assert.ok(filePart.file_data.startsWith("data:application/pdf;base64,"));
    assert.equal(Object.hasOwn(filePart, "file_url"), false);
    assert.equal(JSON.stringify(requests[0]).includes("/private/research"), false);
  } finally {
    for (const [name, value] of Object.entries({
      REQUESTY_PDF_MODEL: previous.model,
      REQUESTY_PDF_ENABLED: previous.pdf,
      REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA: previous.schema,
      REQUESTY_PDF_SUPPORTS_JSON_SCHEMA: previous.combination
    })) {
      if (value === undefined) delete process.env[name];
      else process.env[name] = value;
    }
  }
});

test("canonical Paper Card uses one direct native PDF request with its narrow strict schema", async () => {
  const previous = {
    model: process.env.REQUESTY_PDF_MODEL,
    pdf: process.env.REQUESTY_PDF_ENABLED,
    schema: process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA,
    combination: process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA
  };
  process.env.REQUESTY_PDF_MODEL = "openai/gpt-4.1";
  process.env.REQUESTY_PDF_ENABLED = "true";
  process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "true";
  process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA = "true";
  const requestStart = capturedLlmRequests.length;
  queuedChatCompletionTexts.push(JSON.stringify(validNativePaperCard()));
  try {
    const response = await handler(
      apiEvent("POST", "/api/literature/analyze-pdf-native", {
        paperId: "paper-card-native",
        filename: "/private/workspace/literature/中文论文.pdf",
        contentHash: "sha256:paper-card-native",
        task: "Create a comprehensive question-independent Paper Card.",
        purpose: "canonical-paper-card",
        responseSchema: "canonical_paper_card",
        fileData: `data:application/pdf;base64,${Buffer.from("%PDF-1.4\nnative-paper-card").toString("base64")}`
      }),
      context
    );
    const body = parseResponse(response);
    const requests = capturedLlmRequests.slice(requestStart);

    assert.equal(response.statusCode, 200);
    assert.equal(body.analysis.sourceIdentity.paperId, "paper-card-native");
    assert.equal(body.analysis.majorFindings[0].citations[0].page, 4);
    assert.equal(body.diagnostics.generationMode, "native-pdf");
    assert.equal(body.attempts, 1);
    assert.match(body.modelSignature, /^[a-f0-9]{64}$/);
    assert.equal(body.schemaVersion, 1);
    assert.equal(body.promptVersion, "canonical-paper-card-native-v1");
    assert.equal(requests.length, 1);
    assert.equal(
      requests[0].response_format.json_schema.name,
      "canonical_native_pdf_paper_card"
    );
    assert.equal(requests[0].response_format.json_schema.strict, true);
    assert.equal(JSON.stringify(requests[0]).includes("/private/workspace"), false);
  } finally {
    for (const [name, value] of Object.entries({
      REQUESTY_PDF_MODEL: previous.model,
      REQUESTY_PDF_ENABLED: previous.pdf,
      REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA: previous.schema,
      REQUESTY_PDF_SUPPORTS_JSON_SCHEMA: previous.combination
    })) {
      if (value === undefined) delete process.env[name];
      else process.env[name] = value;
    }
  }
});

test("native Paper Card exposes Requesty authentication failure as terminal", async () => {
  const previous = {
    model: process.env.REQUESTY_PDF_MODEL,
    pdf: process.env.REQUESTY_PDF_ENABLED,
    schema: process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA,
    combination: process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA
  };
  process.env.REQUESTY_PDF_MODEL = "openai/gpt-4.1";
  process.env.REQUESTY_PDF_ENABLED = "true";
  process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "true";
  process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA = "true";
  const requestStart = capturedLlmRequests.length;
  queuedChatHttpStatuses.push(401);
  try {
    const response = await handler(
      apiEvent("POST", "/api/literature/analyze-pdf-native", {
        paperId: "paper-card-native",
        filename: "paper.pdf",
        contentHash: "sha256:paper-card-native",
        task: "Create a comprehensive question-independent Paper Card.",
        purpose: "canonical-paper-card",
        responseSchema: "canonical_paper_card",
        fileData: `data:application/pdf;base64,${Buffer.from("%PDF-1.4\nauth-failure").toString("base64")}`
      }),
      context
    );
    const body = parseResponse(response);
    assert.equal(response.statusCode, 502);
    assert.equal(body.terminalProviderFailure, true);
    assert.equal(body.attempts, 1);
    assert.equal(capturedLlmRequests.slice(requestStart).length, 1);
  } finally {
    for (const [name, value] of Object.entries({
      REQUESTY_PDF_MODEL: previous.model,
      REQUESTY_PDF_ENABLED: previous.pdf,
      REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA: previous.schema,
      REQUESTY_PDF_SUPPORTS_JSON_SCHEMA: previous.combination
    })) {
      if (value === undefined) delete process.env[name];
      else process.env[name] = value;
    }
  }
});

test("canonical Paper Card rejects mismatched provenance without repair or a second provider call", async () => {
  const previous = {
    model: process.env.REQUESTY_PDF_MODEL,
    pdf: process.env.REQUESTY_PDF_ENABLED,
    schema: process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA,
    combination: process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA
  };
  process.env.REQUESTY_PDF_MODEL = "openai/gpt-4.1";
  process.env.REQUESTY_PDF_ENABLED = "true";
  process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "true";
  process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA = "true";
  const requestStart = capturedLlmRequests.length;
  queuedChatCompletionTexts.push(JSON.stringify(validNativePaperCard({
    source_identity: {
      paper_id: "wrong-paper",
      content_hash: "sha256:paper-card-native"
    }
  })));
  try {
    const response = await handler(
      apiEvent("POST", "/api/literature/analyze-pdf-native", {
        paperId: "paper-card-native",
        filename: "paper.pdf",
        contentHash: "sha256:paper-card-native",
        task: "Create a comprehensive question-independent Paper Card.",
        purpose: "canonical-paper-card",
        responseSchema: "canonical_paper_card",
        fileData: `data:application/pdf;base64,${Buffer.from("%PDF-1.4\ninvalid-provenance").toString("base64")}`
      }),
      context
    );
    const body = parseResponse(response);
    assert.equal(response.statusCode, 502);
    assert.equal(body.fallbackReason, "native-schema-or-provenance-invalid");
    assert.equal(body.attempts, 1);
    assert.equal(capturedLlmRequests.slice(requestStart).length, 1);
  } finally {
    for (const [name, value] of Object.entries({
      REQUESTY_PDF_MODEL: previous.model,
      REQUESTY_PDF_ENABLED: previous.pdf,
      REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA: previous.schema,
      REQUESTY_PDF_SUPPORTS_JSON_SCHEMA: previous.combination
    })) {
      if (value === undefined) delete process.env[name];
      else process.env[name] = value;
    }
  }
});

test("canonical Paper Card makes no provider request when direct PDF structured output is unsupported", async () => {
  const previous = {
    model: process.env.REQUESTY_PDF_MODEL,
    pdf: process.env.REQUESTY_PDF_ENABLED,
    schema: process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA,
    combination: process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA
  };
  process.env.REQUESTY_PDF_MODEL = "anthropic/claude-sonnet-4";
  process.env.REQUESTY_PDF_ENABLED = "true";
  process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "true";
  process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA = "false";
  const requestStart = capturedLlmRequests.length;
  try {
    const response = await handler(
      apiEvent("POST", "/api/literature/analyze-pdf-native", {
        paperId: "paper-card-native",
        filename: "paper.pdf",
        contentHash: "sha256:paper-card-native",
        task: "Create a comprehensive question-independent Paper Card.",
        purpose: "canonical-paper-card",
        responseSchema: "canonical_paper_card",
        fileData: `data:application/pdf;base64,${Buffer.from("%PDF-1.4\nunsupported").toString("base64")}`
      }),
      context
    );
    const body = parseResponse(response);
    assert.equal(response.statusCode, 422);
    assert.equal(body.fallbackReason, "native-structured-output-unsupported");
    assert.equal(body.attempts, 0);
    assert.equal(capturedLlmRequests.slice(requestStart).length, 0);
  } finally {
    for (const [name, value] of Object.entries({
      REQUESTY_PDF_MODEL: previous.model,
      REQUESTY_PDF_ENABLED: previous.pdf,
      REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA: previous.schema,
      REQUESTY_PDF_SUPPORTS_JSON_SCHEMA: previous.combination
    })) {
      if (value === undefined) delete process.env[name];
      else process.env[name] = value;
    }
  }
});

test("combined extracted text creates the canonical Paper Card in one strict Requesty call", async () => {
  assert.deepEqual(
    _test.COMBINED_TEXT_PAPER_CARD_RESPONSE_FORMAT.json_schema.schema,
    _test.NATIVE_PAPER_CARD_RESPONSE_FORMAT.json_schema.schema
  );
  const requestStart = capturedLlmRequests.length;
  queuedChatCompletionTexts.push(JSON.stringify(validNativePaperCard()));
  const response = await handler(
    apiEvent("POST", "/api/literature/create-paper-card-from-text", {
      paperId: "paper-card-native",
      filename: "/private/workspace/literature/中文论文.pdf",
      contentHash: "sha256:paper-card-native",
      text:
        "# Page 1\nIntroduction and methods.\n\n# Page 4\nThe tested variant improved EctD activity.",
      pageCount: 4,
      chunkCount: 5,
      extractionTruncated: false,
      callContext: {
        turnId: "turn-combined",
        workflowId: "workflow-combined",
        callRole: "combined_text_paper_card",
        paperId: "paper-card-native",
        profile: "high"
      }
    }),
    context
  );
  const body = parseResponse(response);
  const requests = capturedLlmRequests.slice(requestStart);

  assert.equal(response.statusCode, 200);
  assert.equal(body.analysis.sourceIdentity.paperId, "paper-card-native");
  assert.equal(body.analysis.sourceIdentity.contentHash, "sha256:paper-card-native");
  assert.equal(body.diagnostics.generationMode, "combined-text");
  assert.equal(body.diagnostics.chunkCount, 5);
  assert.equal(body.schemaVersion, 1);
  assert.equal(body.promptVersion, "canonical-paper-card-combined-text-v2");
  assert.match(body.modelSignature, /^[a-f0-9]{64}$/);
  assert.equal(requests.length, 1);
  assert.equal(
    requests[0].response_format.json_schema.name,
    "canonical_combined_text_paper_card"
  );
  assert.equal(requests[0].response_format.json_schema.strict, true);
  assert.match(requests[0].messages[0].content, /stable English/);
  assert.equal(JSON.stringify(requests[0]).includes("/private/workspace"), false);
});

test("combined Paper Card rejects invalid provenance without a repair call", async () => {
  const requestStart = capturedLlmRequests.length;
  queuedChatCompletionTexts.push(JSON.stringify(validNativePaperCard({
    source_identity: {
      paper_id: "stale-paper",
      content_hash: "sha256:paper-card-native"
    }
  })));
  const response = await handler(
    apiEvent("POST", "/api/literature/create-paper-card-from-text", {
      paperId: "paper-card-native",
      filename: "paper.pdf",
      contentHash: "sha256:paper-card-native",
      text: "# Page 4\nThe tested variant improved EctD activity.",
      pageCount: 4,
      chunkCount: 1,
      callContext: {
        turnId: "turn-invalid-combined",
        workflowId: "workflow-invalid-combined",
        callRole: "combined_text_paper_card",
        paperId: "paper-card-native",
        profile: "light"
      }
    }),
    context
  );
  const body = parseResponse(response);
  assert.equal(response.statusCode, 502);
  assert.equal(body.fallbackReason, "combined-text-schema-or-provenance-invalid");
  assert.equal(body.verifiedContextLengthError, false);
  assert.equal(capturedLlmRequests.slice(requestStart).length, 1);
});

test("Paper Cards use one validated json_object call when strict schema support is false or unset", async () => {
  const previous = process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA;
  try {
    for (const value of ["false", undefined]) {
      if (value === undefined) delete process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA;
      else process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = value;
      const config = parseResponse(await handler(apiEvent("GET", "/api/literature/config"), context));
      assert.equal(config.combinedTextSupported, true);
      assert.equal(config.combinedTextOutputMode, "json_object");
      const start = capturedLlmRequests.length;
      queuedChatCompletionTexts.push(JSON.stringify(validNativePaperCard()));
      const response = await handler(apiEvent("POST", "/api/literature/create-paper-card-from-text", {
        paperId: "paper-card-native", contentHash: "sha256:paper-card-native", filename: "paper.pdf",
        text: "# Page 4\nThe tested variant improved EctD activity.", pageCount: 4, chunkCount: 1,
        callContext: { turnId: "json-card", callRole: "combined_text_paper_card", paperId: "paper-card-native", profile: "medium" },
      }), context);
      const body = parseResponse(response), requests = capturedLlmRequests.slice(start);
      assert.equal(response.statusCode, 200);
      assert.equal(body.diagnostics.structuredOutputMode, "combined-text+json_object");
      assert.equal(body.analysis.sourceIdentity.contentHash, "sha256:paper-card-native");
      assert.equal(body.modelSignature, config.combinedTextModelSignature);
      assert.equal(requests.length, 1);
      assert.deepEqual(requests[0].response_format, { type: "json_object" });
      assert.ok(requests[0].messages[0].content.includes(JSON.stringify(_test.COMBINED_TEXT_PAPER_CARD_RESPONSE_FORMAT.json_schema.schema)));
      process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "true";
      const strict = parseResponse(await handler(apiEvent("GET", "/api/literature/config"), context));
      assert.equal(strict.combinedTextOutputMode, "json_schema");
      assert.notEqual(strict.combinedTextModelSignature, config.combinedTextModelSignature);
    }
  } finally {
    if (previous === undefined) delete process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA;
    else process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = previous;
  }
});

test("JSON object card output still rejects wrong source identity and malformed fields", async () => {
  const previous = process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA;
  process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "false";
  try {
    for (const invalid of [
      validNativePaperCard({ source_identity: { paper_id: "another-paper", content_hash: "sha256:paper-card-native" } }),
      validNativePaperCard({ methods: "wrong type" }),
      { short_summary: "A valid JSON object is not sufficient for a canonical card." },
    ]) {
      const start = capturedLlmRequests.length;
      queuedChatCompletionTexts.push(JSON.stringify(invalid));
      const response = await handler(apiEvent("POST", "/api/literature/create-paper-card-from-text", {
        paperId: "paper-card-native", contentHash: "sha256:paper-card-native", filename: "paper.pdf",
        text: "# Page 4\nThe tested variant improved EctD activity.",
        callContext: { turnId: "invalid-json-card", callRole: "combined_text_paper_card", paperId: "paper-card-native", profile: "medium" },
      }), context);
      assert.equal(response.statusCode, 502);
      assert.equal(parseResponse(response).fallbackReason, "combined-text-schema-or-provenance-invalid");
      assert.equal(capturedLlmRequests.length - start, 1);
    }
  } finally {
    if (previous === undefined) delete process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA;
    else process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = previous;
  }
});

test("an L2-blocked project resumes through the real FC JSON fallback and persists canonical cards, mirrors and topics", async () => {
  const { createFixture } = require("./helpers/preflight-fixture.js");
  const { LiteratureApiClient } = require("../../docs/literature-module.js");
  const previous = process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA;
  process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "false";
  try {
    const fixture = await createFixture();
    fixture.workspace.set("literature/P1.pdf", "The tested variant improved EctD activity.");
    const api = new LiteratureApiClient({
      baseUrl: "https://fc.test", getHeaders: () => ({ Authorization: `Bearer ${authToken}` }),
      fetch: async (url, options) => {
        const response = await handler({ httpMethod: options.method, path: new URL(url).pathname, headers: options.headers, body: options.body }, context);
        return new Response(response.body, { status: response.statusCode, headers: response.headers });
      },
    });
    fixture.literature.api = api;
    fixture.system.preparation.setPaperCardGenerator((input) => fixture.literature.generatePaperCardFromPrepared(input));
    let oldCapabilityGate = true;
    fixture.system.preparation.getPaperCardConfiguration = async () => {
      const config = await api.getPaperCardConfiguration();
      return oldCapabilityGate ? { ...config, combinedTextSupported: false } : config;
    };
    const start = capturedLlmRequests.length;
    const blocked = await fixture.pipeline.preflight({ turnId: "old-backend" });
    assert.equal(blocked.report.failures[0].code, "COMBINED_TEXT_PAPER_CARD_UNAVAILABLE");
    assert.equal(capturedLlmRequests.length, start);
    const source = fixture.system.registry.list()[0];
    assert.equal(source.knowledgeSync.stages.l1, "ready");
    oldCapabilityGate = false;
    queuedChatCompletionTexts.push(JSON.stringify(validNativePaperCard({
      source_identity: { paper_id: source.sourceId, content_hash: source.contentHash },
      major_findings: [{ claim: "The tested variant improved EctD activity.", citations: [{ page: 1, quote: "variant improved EctD activity" }] }],
    })));
    const resumed = await fixture.pipeline.preflight({ turnId: "fixed-backend" });
    assert.equal(resumed.report.status, "completed", JSON.stringify(resumed.report.failures));
    assert.equal(resumed.report.updated.paperCards, 1);
    assert.equal(fixture.calls.parses, 1);
    assert.equal(capturedLlmRequests.length - start, 1);
    assert.equal(source.knowledgeSync.status, "SYNC_READY");
    assert.equal(await fixture.workspace.fileExists(source.artifacts.paperCard.path), true);
    assert.equal(await fixture.workspace.fileExists(source.artifacts.paperCardMarkdown.path), true);
    assert.equal(source.artifacts.topicMembership.contentHash, source.contentHash);
    assert.ok(fixture.system.topicService.topics.some((topic) => topic.paperIds.includes(source.sourceId)));
    assert.equal((await fixture.workspace.readJson(source.artifacts.paperCard.path)).source.hash, source.contentHash);
    assert.equal((await fixture.pipeline.preflight({ turnId: "reused" })).telemetry.syncAgentSpawned, false);
    assert.equal(capturedLlmRequests.length - start, 1);
    assert.deepEqual(fixture.workspace.state.agent.currentRecommendation, { id: "R1" });
  } finally {
    if (previous === undefined) delete process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA;
    else process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = previous;
  }
});

test("two added long papers recover from a real FC input-token quota response and persist L2/L3 without redoing three ready papers", async () => {
  const { createFixture } = require("./helpers/preflight-fixture.js");
  const { LiteratureApiClient } = require("../../docs/literature-module.js");
  const fixture = await createFixture();
  for (let i = 1; i <= 3; i++) fixture.workspace.set(`literature/P${i}.pdf`, "The tested variant improved EctD activity.");
  await fixture.pipeline.preflight({ turnId: "seed-three" });
  const originalCards = fixture.system.registry.list().map(source => ({ id: source.sourceId, card: fixture.workspace.files.get(source.artifacts.paperCard.path) }));
  const savedFetch = global.fetch;
  let clock = 0, fullCalls = 0, peak = 0, active = 0;
  let releaseInitialPair;
  const initialPair = new Promise(resolve => { releaseInitialPair = resolve; });
  const waits = [], excerptLengths = [], synthesisLengths = [];
  global.fetch = async (url, options) => {
    const request = JSON.parse(options.body);
    if (request.messages?.[0]?.content?.includes("complete bounded text for one academic paper")) {
      fullCalls++;
      if (fullCalls === 2) releaseInitialPair();
      await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error("The second paper-card provider request never started concurrently")), 5000);
        initialPair.then(() => { clearTimeout(timeout); resolve(); });
      });
      return new Response(JSON.stringify({ error: { message: "Quota exceeded for metric: generativelanguage.googleapis.com/generate_content_paid_tier_3_input_token_count, limit: 16000, model: gemma-4-31b\nPlease retry in 22.454788929s." } }), { status: 429, headers: { "Retry-After": "23" } });
    }
    if (request.messages?.[0]?.content?.includes("one excerpt of an academic paper")) {
      return new Response(JSON.stringify({ choices: [{ message: { content: JSON.stringify({ summary: "Evidence summary. ".repeat(210),
        mainFindings: ["The tested variant improved EctD activity."] }) } }] }));
    }
    active++; peak = Math.max(peak, active);
    try { return await savedFetch(url, options); } finally { active--; }
  };
  try {
    const api = new LiteratureApiClient({ baseUrl: "https://fc.test", now: () => clock,
      wait: async ms => { waits.push(ms); clock += ms; }, getHeaders: () => ({ Authorization: `Bearer ${authToken}` }),
      fetch: async (url, options) => {
        const endpoint = new URL(url).pathname, body = options.body ? JSON.parse(options.body) : null;
        if (endpoint.endsWith("summarize-chunk")) excerptLengths.push(body.text.length);
        if (endpoint.endsWith("synthesize")) synthesisLengths.push(JSON.stringify(body.chunkSummaries).length);
        const result = await handler({ httpMethod: options.method, path: endpoint, headers: options.headers, body: options.body }, context);
        if (endpoint.endsWith("create-paper-card-from-text")) {
          const error = JSON.parse(result.body);
          assert.equal(result.statusCode, 429);
          assert.equal(error.providerStatus, 429);
          assert.equal(error.retryAfterMs, 23000);
          assert.equal(error.inputTokenLimit, 16000);
          assert.equal(error.attempts, 1, "FC must not retry before the provider reset");
        }
        return new Response(result.body, { status: result.statusCode, headers: result.headers });
      },
    });
    fixture.literature.api = api;
    fixture.system.preparation.setPaperCardGenerator(input => fixture.literature.generatePaperCardFromPrepared(input));
    fixture.system.preparation.getPaperCardConfiguration = () => api.getPaperCardConfiguration();
    for (const [name, size] of [["P4", 75014], ["P5", 109877]]) {
      fixture.workspace.set(`literature/${name}.pdf`, "The tested variant improved EctD activity. ".repeat(3000).slice(0, size));
    }
    const result = await fixture.pipeline.preflight({ turnId: "add-two-long-papers" });
    assert.equal(result.report.status, "completed", JSON.stringify(result.report.failures));
    assert.equal(result.report.updated.paperCards, 2);
    assert.equal(fullCalls, 2, "Both new papers must reach the provider concurrently before the quota is learned");
    assert.equal(api.paperCardConcurrency, 1);
    assert.deepEqual(waits, [24000]);
    assert.equal(peak, 1);
    assert.ok(excerptLengths.length >= 19 && excerptLengths.every(length => length <= 10000));
    assert.ok(synthesisLengths.length > 2 && synthesisLengths.every(length => length <= 28000), "Synthesis must also fit the learned quota without discarding excerpts");
    for (const id of result.diff.added) {
      const source = fixture.system.registry.get(id), card = await fixture.workspace.readJson(source.artifacts.paperCard.path);
      assert.equal(source.knowledgeSync.status, "SYNC_READY");
      assert.equal(card.generationMode, "map-reduce");
      assert.equal(card.source.hash, source.contentHash);
      assert.ok(await fixture.workspace.fileExists(source.artifacts.paperCardMarkdown.path));
      assert.ok(source.artifacts.topicMembership);
    }
    for (const original of originalCards) assert.equal(fixture.workspace.files.get(fixture.system.registry.get(original.id).artifacts.paperCard.path), original.card);
    const requestCount = excerptLengths.length;
    assert.equal((await fixture.pipeline.preflight({ turnId: "unchanged-after-recovery" })).telemetry.syncAgentSpawned, false);
    assert.equal(excerptLengths.length, requestCount);
    assert.equal(fixture.calls.parses, 5);
  } finally { global.fetch = savedFetch; }
});

test("only explicit Requesty context-size responses are classified as context-size errors", () => {
  assert.equal(
    _test.isVerifiedContextLengthError(
      400,
      JSON.stringify({ error: { code: "context_length_exceeded", message: "too long" } })
    ),
    true
  );
  assert.equal(
    _test.isVerifiedContextLengthError(
      413,
      JSON.stringify({ error: { message: "Maximum context length exceeded" } })
    ),
    true
  );
  assert.equal(
    _test.isVerifiedContextLengthError(
      401,
      JSON.stringify({ error: { message: "Maximum context length exceeded" } })
    ),
    false
  );
  assert.equal(
    _test.isVerifiedContextLengthError(
      502,
      JSON.stringify({ error: { message: "upstream unavailable" } })
    ),
    false
  );
});

test("native PDF falls back to two-step strict extraction when PDF plus json_schema is unsupported", async () => {
  const previous = {
    model: process.env.REQUESTY_PDF_MODEL,
    schema: process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA,
    combination: process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA
  };
  process.env.REQUESTY_PDF_MODEL = "anthropic/claude-sonnet-4";
  process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "true";
  process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA = "false";
  const requestStart = capturedLlmRequests.length;
  queuedChatCompletionTexts.push(
    "The private PDF reports a controlled activity assay.",
    JSON.stringify(validNativePaperAnalysis())
  );
  try {
    const response = await handler(
      apiEvent("POST", "/api/literature/analyze-pdf-native", {
        paperId: "paper-native",
        filename: "paper-native.pdf",
        contentHash: "sha256:native",
        task: "Recover a structured whole-paper analysis.",
        fileData: `data:application/pdf;base64,${Buffer.from("%PDF-1.4\ntwo-step-private-content").toString("base64")}`
      }),
      context
    );
    const body = parseResponse(response);
    const requests = capturedLlmRequests.slice(requestStart);

    assert.equal(response.statusCode, 200);
    assert.equal(body.diagnostics.structuredOutputMode, "two-step-json_schema");
    assert.equal(requests.length, 2);
    assert.equal(requests[0].response_format, undefined);
    assert.ok(requests[0].messages[1].content.some((part) => part.type === "input_file"));
    assert.equal(requests[1].response_format.type, "json_schema");
    assert.equal(
      requests[1].messages.some((message) =>
        Array.isArray(message.content) &&
        message.content.some((part) => part.type === "input_file")
      ),
      false
    );
  } finally {
    for (const [name, value] of Object.entries({
      REQUESTY_PDF_MODEL: previous.model,
      REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA: previous.schema,
      REQUESTY_PDF_SUPPORTS_JSON_SCHEMA: previous.combination
    })) {
      if (value === undefined) delete process.env[name];
      else process.env[name] = value;
    }
  }
});

test("invalid native structured output is repaired with bounded schema-constrained retry", async () => {
  const previous = {
    model: process.env.REQUESTY_PDF_MODEL,
    schema: process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA,
    combination: process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA
  };
  process.env.REQUESTY_PDF_MODEL = "anthropic/claude-sonnet-4";
  process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "true";
  process.env.REQUESTY_PDF_SUPPORTS_JSON_SCHEMA = "true";
  const requestStart = capturedLlmRequests.length;
  queuedChatCompletionTexts.push(
    "This response is useful analysis but not valid structured JSON.",
    JSON.stringify(validNativePaperAnalysis())
  );
  try {
    const response = await handler(
      apiEvent("POST", "/api/literature/analyze-pdf-native", {
        paperId: "paper-native-repair",
        filename: "paper-native-repair.pdf",
        contentHash: "sha256:native-repair",
        task: "Summarize this whole paper.",
        fileData: `data:application/pdf;base64,${Buffer.from("%PDF-1.4\nprivate-repair-content").toString("base64")}`
      }),
      context
    );
    const body = parseResponse(response);
    const requests = capturedLlmRequests.slice(requestStart);

    assert.equal(response.statusCode, 200);
    assert.equal(body.diagnostics.structuredOutputMode, "structured-repair-json_schema");
    assert.equal(body.diagnostics.fallbackPath, "native-pdf-structured-repair");
    assert.equal(requests.length, 2);
    assert.equal(requests[1].response_format.json_schema.strict, true);
  } finally {
    for (const [name, value] of Object.entries({
      REQUESTY_PDF_MODEL: previous.model,
      REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA: previous.schema,
      REQUESTY_PDF_SUPPORTS_JSON_SCHEMA: previous.combination
    })) {
      if (value === undefined) delete process.env[name];
      else process.env[name] = value;
    }
  }
});

test("json_schema-unsupported corpus mapping sends the complete schema in one json_object call", async () => {
  const previous = process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA;
  process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "false";
  const requestStart = capturedLlmRequests.length;
  const evidenceRef = "paper-fallback:p2:chunk-1";
  queuedCorpusMapCompletionTexts.push(
    JSON.stringify(validCorpusMapJson(evidenceRef))
  );
  try {
    const response = await handler(
      apiEvent("POST", "/api/corpus/map-paper", {
        paperId: "paper-fallback",
        contentHash: "sha256:fallback",
        question: "What did the paper find?",
        evidence: [
          {
            evidenceRef,
            text: "A163V improved activity in the reported assay."
          }
        ]
      }),
      context
    );
    const body = parseResponse(response);
    const requests = capturedLlmRequests.slice(requestStart);

    assert.equal(response.statusCode, 200);
    assert.equal(body.mapResult.paperId, "paper-fallback");
    assert.equal(requests.length, 1);
    assert.deepEqual(requests[0].response_format, { type: "json_object" });
    const fallbackPrompt = requests[0].messages[0].content;
    assert.ok(fallbackPrompt.includes(JSON.stringify(_test.CORPUS_MAP_SCHEMA)));
    const expectedTypes = {
      title: "string",
      relevance: "string",
      research_question: "string or null",
      themes: "array of strings",
      methods: "array of strings",
      organisms: "array of strings",
      genes: "array of strings",
      proteins: "array of strings",
      pathways: "array of strings",
      experimental_strategies: "array of strings",
      major_findings: "array of objects",
      limitations: "array of strings",
      connections_to_other_topics: "array of strings",
      notes: "string or null"
    };
    for (const [key, type] of Object.entries(expectedTypes)) {
      assert.ok(fallbackPrompt.includes(`- "${key}": ${type}`));
    }
    assert.match(fallbackPrompt, /No additional top-level keys/);
    assert.match(fallbackPrompt, /"major_findings": array of objects/);
    assert.match(fallbackPrompt, /"claim" \(string\)/);
    assert.match(fallbackPrompt, /"evidence_refs" \(array of strings\)/);
    assert.match(fallbackPrompt, new RegExp(evidenceRef.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
    assert.deepEqual(body.mapResult.findings[0].evidenceRefs, [evidenceRef]);
    assert.equal(body.mapperDiagnostics.structuredOutputMode, "json_object");
    assert.equal(body.mapperDiagnostics.repairAttempted, false);
  } finally {
    if (previous === undefined) delete process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA;
    else process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = previous;
  }
});

test("schema-invalid corpus JSON receives one bounded repair without paper reanalysis", async () => {
  const previous = process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA;
  process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = "true";
  const requestStart = capturedLlmRequests.length;
  const evidenceRef = "paper-repair:p7:chunk-2";
  const guessedResponse = {
    summary: "The variant improved activity.",
    key_findings: ["The variant improved activity."],
    methodology: "Activity assay",
    conclusion: "The variant was beneficial."
  };
  queuedCorpusMapCompletionTexts.push(
    JSON.stringify(guessedResponse),
    JSON.stringify(validCorpusMapJson(evidenceRef))
  );
  try {
    const response = await handler(
      apiEvent("POST", "/api/corpus/map-paper", {
        paperId: "paper-repair",
        contentHash: "sha256:repair",
        question: "Which variant improved activity?",
        evidence: [
          {
            evidenceRef,
            text: "The A163V variant improved activity in the reported assay."
          }
        ]
      }),
      context
    );
    const body = parseResponse(response);
    const requests = capturedLlmRequests.slice(requestStart);

    assert.equal(response.statusCode, 200);
    assert.equal(requests.length, 2);
    assert.equal(requests[0].response_format.type, "json_schema");
    assert.equal(requests[1].response_format.type, "json_schema");
    assert.match(requests[1].messages[0].content, /Correct the previous JSON only/);
    assert.ok(
      requests[1].messages[0].content.includes(JSON.stringify(_test.CORPUS_MAP_SCHEMA))
    );
    assert.match(requests[1].messages[1].content, /title is required\./);
    assert.match(requests[1].messages[1].content, /summary is not allowed\./);
    assert.match(requests[1].messages[1].content, /Previous JSON response:/);
    assert.ok(requests[1].messages[1].content.includes(JSON.stringify(guessedResponse)));
    assert.doesNotMatch(
      requests[1].messages.map((message) => message.content).join("\n"),
      /Which variant improved activity\?|A163V variant improved activity in the reported assay/
    );
    assert.equal(body.mapperDiagnostics.repairAttempted, true);
    assert.deepEqual(body.mapResult.findings[0].evidenceRefs, [evidenceRef]);
  } finally {
    if (previous === undefined) delete process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA;
    else process.env.REQUESTY_MODEL_SUPPORTS_JSON_SCHEMA = previous;
  }
});

test("corpus schema validation reports exact missing and unexpected keys", () => {
  const guessedResponse = {
    summary: "Summary",
    key_findings: [],
    methodology: "Assay",
    conclusion: "Conclusion"
  };
  const errors = _test.validateNativeCorpusMap(guessedResponse);

  assert.deepEqual(
    errors.filter((error) => error.endsWith(" is required.")),
    _test.CORPUS_MAP_SCHEMA.required.map((key) => `${key} is required.`)
  );
  assert.deepEqual(
    errors.filter((error) => error.endsWith(" is not allowed.")),
    [
      "summary is not allowed.",
      "key_findings is not allowed.",
      "methodology is not allowed.",
      "conclusion is not allowed."
    ]
  );
});

test("corpus schema validation rejects evidence references outside the supplied set", () => {
  const mapped = validCorpusMapJson("invented-reference");
  assert.deepEqual(
    _test.validateNativeCorpusMap(mapped, new Set(["paper-a:p8:paper-a-P8-C2"])),
    [
      "major_findings[0].evidence_refs[0] must exactly match a supplied evidence reference."
    ]
  );
});

test("context router uses only compact indexes and preserves explicit paper scope", async () => {
  queuedRouterCompletionTexts.push(
    JSON.stringify({
      use_literature: true,
      paper_ids: ["paper-b"],
      use_project_memory: true,
      memory_ids: ["project_summary", "not-available"],
      reason: "The question asks about the selected study."
    })
  );
  const response = await handler(
    apiEvent("POST", "/api/context/route", {
      userQuery: "What exact value did the selected paper report?",
      selectedPaperIds: ["paper-a"],
      recentlyReferencedPaperIds: ["paper-b"],
      literatureIndex: [
        {
          paperId: "paper-a",
          fileName: "paper-a.pdf",
          title: "Selected EctD study",
          authors: ["A. Scientist"],
          year: 2024,
          topics: ["enzyme engineering"],
          keywords: ["EctD"],
          identifiers: ["A163V"],
          shortDescription: "A compact routing description.",
          status: "ready",
          paperCardAvailable: true,
          fullPaperText: "must not be sent"
        },
        {
          paperId: "paper-b",
          fileName: "paper-b.pdf",
          title: "Unselected study",
          status: "ready",
          paperCardAvailable: true
        }
      ],
      availableMemoryDescriptions: [
        { id: "project_summary", description: "Saved project summary is available." }
      ]
    }),
    context
  );
  const body = parseResponse(response);
  assert.equal(response.statusCode, 200);
  assert.equal(body.ok, true);
  assert.deepEqual(body.routing.paperIds, ["paper-a"]);
  assert.deepEqual(body.routing.memoryIds, ["project_summary"]);

  const request = capturedLlmRequests.at(-1);
  const routerInput = JSON.parse(request.messages.at(-1).content);
  assert.equal(routerInput.literature_index.length, 2);
  assert.equal(
    Object.hasOwn(routerInput.literature_index[0], "fullPaperText"),
    false
  );
  assert.match(request.messages[0].content, /not the answering agent/i);
});

test("context router preserves an explicit scope of 100 papers", async () => {
  const paperIds = Array.from({ length: 100 }, (_, index) => `paper-${index + 1}`);
  queuedRouterCompletionTexts.push(
    JSON.stringify({
      use_literature: true,
      paper_ids: [paperIds[0]],
      use_project_memory: false,
      memory_ids: [],
      reason: "Use the complete explicitly selected paper scope."
    })
  );

  const response = await handler(
    apiEvent("POST", "/api/context/route", {
      userQuery: "Compare every selected paper.",
      selectedPaperIds: paperIds,
      literatureIndex: paperIds.map((paperId, index) => ({
        paperId,
        fileName: `${paperId}.pdf`,
        title: `Study ${index + 1}`,
        status: "ready",
        paperCardAvailable: true
      }))
    }),
    context
  );
  const body = parseResponse(response);
  assert.equal(response.statusCode, 200);
  assert.deepEqual(body.routing.paperIds, paperIds);

  const routerInput = JSON.parse(capturedLlmRequests.at(-1).messages.at(-1).content);
  assert.equal(routerInput.selected_paper_ids.length, 100);
  assert.equal(routerInput.literature_index.length, 100);
});

test("authenticated PDF upload URL uses an owned, sanitized key", async () => {
  const response = await handler(
    apiEvent("POST", "/api/documents/upload-url", {
      filename: "../../Unsafe Paper.pdf",
      contentType: "application/pdf",
      size: 1200
    }),
    context
  );
  const body = parseResponse(response);

  assert.equal(response.statusCode, 200);
  assert.equal(body.ok, true);
  assert.match(
    body.objectKey,
    /^uploads\/paper-reviewer-example-com-[a-f0-9]{16}\//
  );
  assert.match(body.objectKey, /\/Unsafe-Paper\.pdf$/);
  assert.equal(
    _test.isOwnedPdfObjectKey(body.objectKey, process.env.ADMIN_ACCOUNT),
    true
  );
  assert.match(body.uploadUrl, /OSS4-HMAC-SHA256/);
  assert.match(body.uploadUrl, /oss-cn-beijing\.aliyuncs\.com/);
  assert.doesNotMatch(body.uploadUrl, /internal/);
});

test("authenticated document listing discovers only the account's OSS PDFs", async () => {
  const ownKey = _test.buildOwnedPdfObjectKey(
    process.env.ADMIN_ACCOUNT,
    "persistent-paper.pdf"
  );
  const foreignKey = _test.buildOwnedPdfObjectKey(
    "different-user@example.com",
    "private-paper.pdf"
  );
  const pdf = makeMachineReadablePdf();
  objectStore.set(ownKey, {
    buffer: pdf,
    contentType: "application/pdf",
    lastModified: "2026-08-14T03:00:00.000Z"
  });
  objectStore.set(foreignKey, {
    buffer: pdf,
    contentType: "application/pdf",
    lastModified: "2026-08-14T04:00:00.000Z"
  });

  const response = await handler(
    apiEvent("GET", "/api/documents"),
    context
  );
  const body = parseResponse(response);

  assert.equal(response.statusCode, 200);
  assert.equal(body.ok, true);
  assert.deepEqual(body.documents, [
    {
      objectKey: ownKey,
      filename: "persistent-paper.pdf",
      size: pdf.length,
      lastModified: "2026-08-14T03:00:00.000Z",
      type: "application/pdf",
      summaryAvailable: false
    }
  ]);
  assert.equal(body.documents[0].url, undefined);
});

test("upload URL endpoint rejects non-PDF files", async () => {
  const response = await handler(
    apiEvent("POST", "/api/documents/upload-url", {
      filename: "notes.txt",
      contentType: "text/plain",
      size: 100
    }),
    context
  );
  assert.equal(response.statusCode, 415);
  assert.equal(parseResponse(response).stage, "upload");
});

test("upload URL endpoint rejects oversized PDFs", async () => {
  const response = await handler(
    apiEvent("POST", "/api/documents/upload-url", {
      filename: "too-large.pdf",
      contentType: "application/pdf",
      size: 5 * 1024 * 1024 + 1
    }),
    context
  );
  assert.equal(response.statusCode, 413);
  assert.equal(parseResponse(response).error, "InvalidFileSize");
});

test("PDF text is divided into bounded overlapping review chunks", () => {
  const text = Array.from(
    { length: 4000 },
    (_, index) => `Sentence ${index} contains paper evidence. `
  ).join("");
  const result = _test.chunkPdfText(text);

  assert.ok(result.chunks.length > 1);
  assert.ok(result.chunks.every((chunk) => chunk.length <= 12000));
  assert.equal(result.truncated, true);
  assert.equal(result.processedCharacters, 96000);
});

test("machine-readable PDF extraction and review succeed without deleting the object", async () => {
  const pdf = makeMachineReadablePdf();
  const extraction = await _test.extractPdfDocument(pdf);
  assert.equal(extraction.ok, true);
  assert.ok(extraction.text.length >= 200);

  const objectKey = _test.buildOwnedPdfObjectKey(
    process.env.ADMIN_ACCOUNT,
    "review-paper.pdf"
  );
  objectStore.set(objectKey, { buffer: pdf, contentType: "application/pdf" });

  const response = await handler(
    apiEvent("POST", "/api/documents/review", {
      objectKey,
      language: "en"
    }),
    context
  );
  const body = parseResponse(response);

  assert.equal(response.statusCode, 200);
  assert.equal(body.ok, true);
  assert.equal(body.summary, "The paper evaluates a controlled evidence-review workflow.");
  assert.deepEqual(body.key_results, [
    "Source evidence remained available after review."
  ]);
  assert.ok(body.extractedCharacterCount >= 200);
  assert.equal(body.summaryCached, true);
  assert.equal(objectStore.has(objectKey), true);
  assert.equal(deleteCalls, 0);

  const callsAfterFirstReview = llmFetchCalls;
  const cachedResponse = await handler(
    apiEvent("POST", "/api/documents/review", { objectKey, language: "en" }),
    context
  );
  assert.equal(cachedResponse.statusCode, 200);
  assert.equal(parseResponse(cachedResponse).cached, true);
  assert.equal(llmFetchCalls, callsAfterFirstReview);
});

test("deleting an owned PDF removes both the source and cached summary", async () => {
  const objectKey = _test.buildOwnedPdfObjectKey(
    process.env.ADMIN_ACCOUNT,
    "delete-paper.pdf"
  );
  const pdf = makeMachineReadablePdf();
  objectStore.set(objectKey, { buffer: pdf, contentType: "application/pdf" });

  const reviewResponse = await handler(
    apiEvent("POST", "/api/documents/review", { objectKey, language: "en" }),
    context
  );
  assert.equal(reviewResponse.statusCode, 200);
  const reviewObjectKey = objectKey.replace(/[^/]+$/, ".paper-review.json");
  assert.equal(objectStore.has(reviewObjectKey), true);

  const response = await handler(
    apiEvent("POST", "/api/documents/delete", { objectKey }),
    context
  );
  const body = parseResponse(response);
  assert.equal(response.statusCode, 200);
  assert.equal(body.deleted, true);
  assert.equal(objectStore.has(objectKey), false);
  assert.equal(objectStore.has(reviewObjectKey), false);
});

test("missing and foreign PDF objects produce controlled errors", async () => {
  const missingKey = _test.buildOwnedPdfObjectKey(
    process.env.ADMIN_ACCOUNT,
    "missing.pdf"
  );
  const missingResponse = await handler(
    apiEvent("POST", "/api/documents/review", { objectKey: missingKey }),
    context
  );
  assert.equal(missingResponse.statusCode, 404);
  assert.equal(parseResponse(missingResponse).error, "ObjectNotFound");

  const foreignKey = _test.buildOwnedPdfObjectKey(
    "different-user@example.com",
    "foreign.pdf"
  );
  const foreignResponse = await handler(
    apiEvent("POST", "/api/documents/review", { objectKey: foreignKey }),
    context
  );
  assert.equal(foreignResponse.statusCode, 403);
  assert.equal(parseResponse(foreignResponse).error, "ObjectAccessDenied");

  const foreignDeleteResponse = await handler(
    apiEvent("POST", "/api/documents/delete", { objectKey: foreignKey }),
    context
  );
  assert.equal(foreignDeleteResponse.statusCode, 403);
  assert.equal(parseResponse(foreignDeleteResponse).error, "ObjectAccessDenied");
});

test("existing chat can retrieve an owned stored PDF as evidence", async () => {
  const objectKey = _test.buildOwnedPdfObjectKey(
    process.env.ADMIN_ACCOUNT,
    "side-chat-paper.pdf"
  );
  objectStore.set(objectKey, {
    buffer: makeMachineReadablePdf(),
    contentType: "application/pdf"
  });

  const response = await handler(
    apiEvent("POST", "/chat", {
      mode: "side_chat",
      messages: [{ role: "user", content: "What does this paper conclude?" }],
      storedDocuments: [{ objectKey }]
    }),
    context
  );
  const body = parseResponse(response);

  assert.equal(response.statusCode, 200);
  assert.equal(body.reply, "The stored PDF evidence was available to Side Chat.");
  assert.deepEqual(body.storedPdfsUsed, ["side-chat-paper.pdf"]);
});

test("Side Chat accepts plain-text follow-ups and preserves multi-round history", async () => {
  capturedLlmRequests.length = 0;
  queuedChatCompletionTexts.push("The first conversational answer.");
  const firstResponse = await handler(
    apiEvent("POST", "/chat", {
      mode: "side_chat",
      messages: [{ role: "user", content: "Explain the main result." }]
    }),
    context
  );
  const firstBody = parseResponse(firstResponse);
  assert.equal(firstResponse.statusCode, 200);
  assert.equal(firstBody.fallback, false);
  assert.equal(firstBody.reply, "The first conversational answer.");

  queuedChatCompletionTexts.push(
    "The limitation follows from the small validation cohort."
  );
  const secondResponse = await handler(
    apiEvent("POST", "/chat", {
      mode: "side_chat",
      messages: [
        { role: "user", content: "Explain the main result." },
        { role: "assistant", content: firstBody.reply },
        { role: "user", content: "What limitation did you just mention?" }
      ]
    }),
    context
  );
  const secondBody = parseResponse(secondResponse);
  assert.equal(secondResponse.statusCode, 200);
  assert.equal(secondBody.fallback, false);
  assert.equal(
    secondBody.reply,
    "The limitation follows from the small validation cohort."
  );

  const request = capturedLlmRequests.at(-1);
  assert.equal(Object.hasOwn(request, "max_tokens"), false);
  assert.deepEqual(
    request.messages
      .filter((message) => message.role !== "system")
      .map((message) => message.role),
    ["user", "assistant", "user"]
  );
});

test("the long-term project goal is a system message for answers and recommendations", async () => {
  capturedLlmRequests.length = 0;
  const projectGoal =
    "Over the next several weeks, select the best-supported enzyme variant for the final project decision.";

  queuedChatCompletionTexts.push("The answer is framed against the final goal.");
  const sideChatResponse = await handler(
    apiEvent("POST", "/chat", {
      mode: "side_chat",
      projectContext: projectGoal,
      messages: [{ role: "user", content: "How should I interpret this result?" }]
    }),
    context
  );
  assert.equal(sideChatResponse.statusCode, 200);
  const sideChatRequest = capturedLlmRequests.at(-1);
  const sideChatGoalMessage = sideChatRequest.messages.find(
    (message) =>
      message.role === "system" &&
      message.content.includes("Long-term project context and final goal")
  );
  assert.ok(sideChatGoalMessage);
  assert.match(sideChatGoalMessage.content, new RegExp(projectGoal));

  queuedChatCompletionTexts.push(
    JSON.stringify({
      reply: "The recommendation is framed against the final goal.",
      project: {
        summary: "Goal-aware recommendation.",
        organism: "Not specified",
        missingInformation: [],
        safetyLevel: "Planning review",
        safetyNotes: "Human review remains required.",
        draftMemo: "Review the evidence against the final goal."
      }
    })
  );
  const agentWorkResponse = await handler(
    apiEvent("POST", "/chat", {
      mode: "agent_instruction",
      projectContext: projectGoal,
      messages: [{ role: "user", content: "Recommend the next analysis." }]
    }),
    context
  );
  assert.equal(agentWorkResponse.statusCode, 200);
  const agentWorkRequest = capturedLlmRequests.at(-1);
  const agentWorkGoalMessage = agentWorkRequest.messages.find(
    (message) =>
      message.role === "system" &&
      message.content.includes("Long-term project context and final goal")
  );
  assert.ok(agentWorkGoalMessage);
  assert.match(agentWorkGoalMessage.content, new RegExp(projectGoal));
});

test("Side Chat executes provider tool calls through the effect-authorized loop", async () => {
  capturedLlmRequests.length = 0;
  queuedChatCompletionMessages.push(
    {
      content: null,
      tool_calls: [
        {
          id: "read-reference-1",
          type: "function",
          function: {
            name: "read_workspace_item",
            arguments: JSON.stringify({ item_id: "local:1" })
          }
        }
      ]
    },
    {
      content: "The selected reference reports improved A163V activity."
    }
  );

  const response = await handler(
    apiEvent("POST", "/chat", {
      mode: "side_chat",
      messages: [
        { role: "user", content: "What does the selected reference report?" }
      ],
      localWorkspaceContext: {
        scope: {
          type: "files",
          files: ["literature/paper-a.pdf"]
        },
        inventory: [
          {
            paperId: "paper-a",
            name: "paper-a.pdf",
            relativePath: "literature/paper-a.pdf",
            extension: "pdf",
            size: 1200,
            processor: "pdf",
            summaryAvailable: true,
            summaryStatus: "ready"
          }
        ],
        files: [
          {
            paperId: "paper-a",
            name: "paper-a.pdf",
            relativePath: "literature/paper-a.pdf",
            extension: "pdf",
            analysisStatus: "processed",
            evidenceType: "cached-summary",
            content: "The A163V variant showed improved catalytic activity."
          }
        ]
      }
    }),
    context
  );
  const body = parseResponse(response);

  assert.equal(response.statusCode, 200);
  assert.equal(
    body.reply,
    "The selected reference reports improved A163V activity."
  );
  assert.equal(capturedLlmRequests.length, 2);
  assert.deepEqual(
    capturedLlmRequests[0].tools.map((tool) => tool.function.name),
    [
      "list_workspace_items",
      "search_workspace_items",
      "read_workspace_item",
      "read_project_context",
      "list_papers",
      "search_papers",
      "read_paper_evidence",
      "list_experiment_sources",
      "query_experiment_results",
      "get_corpus_workflow_status",
      "source_coverage",
      "update_project_memory",
      "get_local_worker_status",
      "restart_local_worker",
      "update_recommendation"
    ]
  );
  const toolResult = capturedLlmRequests[1].messages.find(
    (message) => message.role === "tool"
  );
  assert.equal(toolResult.tool_call_id, "read-reference-1");
  assert.match(toolResult.content, /A163V variant showed improved/);
});

test("Side Chat preserves a long provider reply without imposing an output cap", async () => {
  const longReply = `## Detailed answer\n\n${Array.from(
    { length: 700 },
    () => "Evidence-backed explanation."
  ).join(" ")}`;
  assert.ok(longReply.length > 12000);
  queuedChatCompletionTexts.push(longReply);

  const response = await handler(
    apiEvent("POST", "/chat", {
      mode: "side_chat",
      messages: [{ role: "user", content: "Give me the complete analysis." }]
    }),
    context
  );
  const body = parseResponse(response);
  assert.equal(response.statusCode, 200);
  assert.equal(body.fallback, false);
  assert.equal(body.reply, longReply);
  assert.equal(
    Object.hasOwn(capturedLlmRequests.at(-1), "max_tokens"),
    false
  );
});

test("Side Chat retries one transient Requesty response", async () => {
  const callsBefore = llmFetchCalls;
  queuedChatHttpStatuses.push(429, 200);
  queuedChatCompletionTexts.push("The retry completed successfully.");
  const response = await handler(
    apiEvent("POST", "/chat", {
      mode: "side_chat",
      messages: [{ role: "user", content: "Please retry this question." }]
    }),
    context
  );
  const body = parseResponse(response);
  assert.equal(response.statusCode, 200);
  assert.equal(body.fallback, false);
  assert.equal(body.reply, "The retry completed successfully.");
  assert.equal(llmFetchCalls - callsBefore, 2);
});

test("chat history is bounded while retaining the latest turn", () => {
  const messages = Array.from({ length: 60 }, (_, index) => ({
    role: index % 2 ? "assistant" : "user",
    content: `${index}:${"x".repeat(3990)}`
  }));
  const sanitized = _test.sanitizeChatMessagesForLlm(messages);
  assert.ok(sanitized.length <= 40);
  assert.equal(sanitized[0].role, "user");
  assert.equal(sanitized.at(-1).content.startsWith("59:"), true);
  assert.ok(
    sanitized.reduce((total, message) => total + message.content.length, 0) <=
      120000
  );
});

test("a long prior Side Chat answer remains available to the next turn", () => {
  const longAnswer = "Prior answer detail. ".repeat(2500).trim();
  const sanitized = _test.sanitizeChatMessagesForLlm([
    { role: "user", content: "Give me a detailed analysis." },
    { role: "assistant", content: longAnswer },
    { role: "user", content: "Now compare its last two sections." }
  ]);

  assert.equal(sanitized[1].content, longAnswer);
  assert.equal(sanitized.at(-1).content, "Now compare its last two sections.");
});

test("side chat routes by cached summaries and avoids loading unrelated PDFs", async () => {
  const pdf = makeMachineReadablePdf();
  const alphaKey = _test.buildOwnedPdfObjectKey(
    process.env.ADMIN_ACCOUNT,
    "alpha-catalyst.pdf"
  );
  const betaKey = _test.buildOwnedPdfObjectKey(
    process.env.ADMIN_ACCOUNT,
    "beta-fermentation.pdf"
  );
  for (const [objectKey, title] of [
    [alphaKey, "Alpha catalyst study"],
    [betaKey, "Beta fermentation study"]
  ]) {
    objectStore.set(objectKey, { buffer: pdf, contentType: "application/pdf" });
    objectStore.set(objectKey.replace(/[^/]+$/, ".paper-review.json"), {
      buffer: Buffer.from(
        JSON.stringify({
          version: 1,
          objectKey,
          filename: objectKey.split("/").pop(),
          language: "en",
          updatedAt: "2026-08-14T06:00:00.000Z",
          review: {
            title,
            summary: `${title} reports a focused validation result.`,
            research_question: `What does ${title} demonstrate?`,
            methods: "Controlled comparison.",
            key_results: [`${title} produced its reported result.`],
            limitations: ["Limited validation scale."],
            main_conclusion: `${title} supports further evaluation.`
          }
        })
      ),
      contentType: "application/json"
    });
  }

  pdfGetCalls = 0;
  const focusedResponse = await handler(
    apiEvent("POST", "/chat", {
      mode: "side_chat",
      messages: [{ role: "user", content: "What does alpha conclude?" }],
      storedDocuments: [
        { objectKey: alphaKey, summaryAvailable: true },
        { objectKey: betaKey, summaryAvailable: true }
      ]
    }),
    context
  );
  const focusedBody = parseResponse(focusedResponse);
  assert.equal(focusedResponse.statusCode, 200);
  assert.deepEqual(focusedBody.storedPdfsUsed, ["alpha-catalyst.pdf"]);
  assert.equal(focusedBody.documentScope.mode, "summary-relevance");
  assert.equal(pdfGetCalls, 1);

  pdfGetCalls = 0;
  const collectionResponse = await handler(
    apiEvent("POST", "/chat", {
      mode: "side_chat",
      messages: [{ role: "user", content: "Summarize all uploaded files." }],
      storedDocuments: [
        { objectKey: alphaKey, summaryAvailable: true },
        { objectKey: betaKey, summaryAvailable: true }
      ],
      selectedDocumentKeys: [alphaKey]
    }),
    context
  );
  const collectionBody = parseResponse(collectionResponse);
  assert.equal(collectionResponse.statusCode, 200);
  assert.deepEqual(collectionBody.storedPdfsUsed, []);
  assert.deepEqual(collectionBody.storedPdfSummariesUsed.sort(), [
    "alpha-catalyst.pdf",
    "beta-fermentation.pdf"
  ]);
  assert.equal(collectionBody.documentScope.mode, "collection-summaries");
  assert.equal(pdfGetCalls, 0);
});

test("collection chat uses cached summaries for twenty papers without loading PDFs", async () => {
  const storedDocuments = [];
  for (let index = 1; index <= 20; index += 1) {
    const objectKey = _test.buildOwnedPdfObjectKey(
      process.env.ADMIN_ACCOUNT,
      `collection-paper-${String(index).padStart(2, "0")}.pdf`
    );
    objectStore.set(objectKey, {
      buffer: makeMachineReadablePdf(),
      contentType: "application/pdf"
    });
    objectStore.set(objectKey.replace(/[^/]+$/, ".paper-review.json"), {
      buffer: Buffer.from(
        JSON.stringify({
          version: 1,
          objectKey,
          filename: objectKey.split("/").pop(),
          language: "en",
          updatedAt: "2026-08-15T02:00:00.000Z",
          review: {
            title: `Collection paper ${index}`,
            summary: `Paper ${index} reports a distinct evidence result.`,
            research_question: `Research question ${index}.`,
            methods: `Method ${index}.`,
            key_results: [`Result ${index}.`],
            limitations: [`Limitation ${index}.`],
            main_conclusion: `Conclusion ${index}.`
          }
        })
      ),
      contentType: "application/json"
    });
    storedDocuments.push({ objectKey, summaryAvailable: true });
  }

  pdfGetCalls = 0;
  queuedChatCompletionTexts.push(
    "The twenty cached paper summaries were compared without loading full PDFs."
  );
  const response = await handler(
    apiEvent("POST", "/chat", {
      mode: "side_chat",
      messages: [
        { role: "user", content: "Compare all twenty papers in the collection." }
      ],
      storedDocuments
    }),
    context
  );
  const body = parseResponse(response);
  assert.equal(response.statusCode, 200);
  assert.equal(body.fallback, false);
  assert.equal(body.documentScope.mode, "collection-summaries");
  assert.equal(body.storedPdfSummariesUsed.length, 20);
  assert.equal(body.storedPdfsUsed.length, 0);
  assert.equal(pdfGetCalls, 0);
});
